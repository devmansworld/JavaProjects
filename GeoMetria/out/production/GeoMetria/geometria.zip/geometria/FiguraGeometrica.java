package geometria;

public interface FiguraGeometrica {
    void area();

}

